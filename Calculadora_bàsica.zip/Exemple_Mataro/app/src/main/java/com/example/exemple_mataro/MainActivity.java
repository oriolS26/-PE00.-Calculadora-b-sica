package com.example.exemple_mataro;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btnSuma;
    private Button btnResta;
    private Button btnMultiplicacio;
    private Button btnDivisio;
    private EditText editOperandoA;
    private EditText editOperandoB;
    private EditText editResultat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btnSuma = findViewById(R.id.btnSuma);
        btnResta = findViewById(R.id.btnResta);
        btnMultiplicacio = findViewById(R.id.btnMultiplicacio);
        btnDivisio = findViewById(R.id.btnDivisio);

        editOperandoA = findViewById(R.id.editOperandoA);
        editOperandoB = findViewById(R.id.editOperandoB);
        editResultat = findViewById(R.id.editResultat);


        btnSuma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                double a = Double.parseDouble(editOperandoA.getText().toString());
                double b = Double.parseDouble(editOperandoB.getText().toString());

                double resultat = a + b;

                editResultat.setText(String.valueOf(resultat));
            }
        });
        btnResta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                double a = Double.parseDouble(editOperandoA.getText().toString());
                double b = Double.parseDouble(editOperandoB.getText().toString());

                double resultat = a - b;

                editResultat.setText(String.valueOf(resultat));
            }
        });

        btnMultiplicacio.setOnClickListener(this);
        btnDivisio.setOnClickListener(this);
    }
        @Override
        public void onClick (View view){

            double a = Double.parseDouble(editOperandoA.getText().toString());
            double b = Double.parseDouble(editOperandoB.getText().toString());

            double resultat;

            if (view.getId() == R.id.btnMultiplicacio) {

                resultat = a * b;

                editResultat.setText(String.valueOf(resultat));

            } else {

                if (b == 0) {
                    editResultat.setText("No es pot dividir per zero");
                } else {
                    resultat = a / b;

                    editResultat.setText(String.valueOf(resultat));
                }
            }
        }
    }
